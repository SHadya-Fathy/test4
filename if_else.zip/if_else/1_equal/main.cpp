#include <iostream>
using namespace std;

int main() {
    int a, b;
    cout << "Enter two integers: ";
    cin >> a >> b;
    if (a == b)
        cout << "The numbers are equal.";
    else
        cout << "The numbers are not equal.";
    return 0;
}
